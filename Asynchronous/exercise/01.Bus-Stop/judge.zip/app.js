function getInfo() {
    let stopId = document.getElementById('stopId');

    let stopIdValue = stopId.value;
    let url = `http://localhost:3030/jsonstore/bus/businfo/${stopIdValue}`;

    let stopNameDiv = document.getElementById('stopName');
    let busesUl = document.getElementById('buses');

    fetch(url)
        .then(response => {
            if (response.ok === false) {
                throw new Error(`Error`);
            }
            if (stopIdValue !== '1287' && stopIdValue !== '1308'
                && stopIdValue !== '1327' && stopIdValue !== '2334') {
                throw new Error(`Error`);
            }
            return response.json();
        })
        .then(data => {

            stopNameDiv.textContent = data.name;

            busesUl.innerHTML = '';
            Object.entries(data.buses).forEach(([k, v]) => {
                let li = document.createElement('li');
                li.textContent = `Bus ${k} arrives in ${v} minutes`;
                busesUl.appendChild(li);
            });
        })
        .catch(err => {
            stopNameDiv.textContent = err.message;
            busesUl.innerHTML = '';
        })
}