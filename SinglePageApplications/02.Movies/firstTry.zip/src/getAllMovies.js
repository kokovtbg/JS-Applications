export async function getMovies() {
    const url = 'http://localhost:3030/data/movies';
    const response = await fetch(url);
    const data = await response.json();
    renderMovies(data);
    return data;
}

function renderMovies(data) {
    const moviesList = document.getElementById('movies-list');
    data.forEach(m => {
        const li = document.createElement('li');
        const sectionMovie = document.createElement('section');
        sectionMovie.classList.add('view-section');
        sectionMovie.id = m._id;
        sectionMovie.innerHTML =
            `<div class="container">
          <div class="row bg-light text-dark">
            <h1>Movie title: ${m.title}</h1>

            <div class="col-md-8">
              <img
                class="img-thumbnail"
                src="${m.img}"
                alt="Movie"
              />
            </div>
            <div class="col-md-4 text-center">
              <h3 class="my-3">Movie Description</h3>
              <p>
                ${m.description}
              </p>
              <a class="btn btn-danger" href="#">Delete</a>
              <a class="btn btn-warning" href="#">Edit</a>
              <a class="btn btn-primary" href="#">Like</a>
              <span class="enrolled-span">Liked 1</span>
            </div>
          </div>
        </div>`;
        li.appendChild(sectionMovie);
        moviesList.appendChild(li);
    })
    Array.from(document.querySelectorAll('#movie ul li a'))
        .forEach(e => e.style.display = 'none');
    Array.from(document.querySelectorAll('#movie ul li span'))
        .forEach(e => e.style.display = 'none');
}