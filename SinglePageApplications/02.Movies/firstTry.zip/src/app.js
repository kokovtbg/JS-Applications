import { addMovie, addMovieSubmit } from "./addMovie.js";
import { login, onLogin, register, onRegister, onLogout } from "./auth.js";
import { getMovies } from "./getAllMovies.js";


document
    .querySelectorAll('#add-movie, #movie-example, #edit-movie, #form-login, #form-sign-up')
    .forEach(e => e.style.display = 'none');
document
    .querySelectorAll('nav ul li.user')
    .forEach(e => e.style.display = 'none');


getMovies();
